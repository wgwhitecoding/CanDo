// static/js/notifications.js

$(document).ready(function(){
    setTimeout(function(){
        $('.alert').fadeOut('slow', function(){
            $(this).remove();
        });
    }, 5000); 
});
